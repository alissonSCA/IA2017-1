from sklearn import datasets
import numpy as np
from Perceptron import Perceptron
import random

miss = 0.0
div = 80

for inf in range(20):
    iris = datasets.load_iris()

    # Pegando tamanho do vetor
    irisLenght = len(iris.data)

    # Atribuindo porcentagem
    firstPart = int((div / 100) * irisLenght)
    #print(firstPart,irisLenght)
    dataX = iris.data
    dataY = np.where(iris.target == 0, 1, -1)

    # Definindo tamanho do array de dados
    arrayData = [0]*len(iris.data)

    #Atribuindo valores ao array e randomizando
    for i in range(irisLenght):
        arrayData[i] = i
    random.shuffle(arrayData)

    neuronsX = [0]*4
    y = 0

    for i in range(irisLenght):
       neuronsX = list(dataX[i])
       y = dataY[i]

       dataX[i] = list(dataX[arrayData[i]])
       dataX[arrayData[i]] = list(neuronsX)
       dataY[i] = dataY[arrayData[i]]
       dataY[arrayData[i]] = y

    # Atribuindo porcentagem ao dataset(nesse caso, 80/20)
    neuronsDataTrainX = dataX[0:firstPart]
    neuronsDataTrainY = dataY[0:firstPart]
    dataSetX = dataX[firstPart:irisLenght]
    dataSetY = dataY[firstPart:irisLenght]

    # Iniciando percentron
    slp = Perceptron()
    slp.treina(neuronsDataTrainX, neuronsDataTrainY)
    errors = 0;

    for xi, yi in zip(dataSetX, dataSetY):
        yh = slp.classifica(xi)
        errors += int(yi != yh)
    miss += errors
    print(errors)

print("erros:", miss)
missesAverage = ((miss/20))# aqui calcula a média dos erros
print("média dos erros:", missesAverage)