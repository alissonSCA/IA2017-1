from AdalineGD import AdalineGD
from matplotlib.colors import ListedColormap
import matplotlib.pyplot as plt
#from TesteGit import TesteGit
import pandas as pd
import numpy as np
from sklearn import datasets
from AdalineSGD import AdalineSGD
from sklearn.linear_model import SGDClassifier
from sklearn.model_selection import train_test_split
from sklearn.datasets import load_diabetes
from sklearn.linear_model import SGDClassifier



def calc(X, y, etaC = 0.01, itera = 10):
    Xl, Xt, yl, yt = train_test_split(X, y, test_size=0.2)

    errosAd2 = []
    errosAd3 = []
    erro2 = 0
    erro3 = 0
    for i in range(0, 20):
        auxError = 0
        Xl, Xt, yl, yt = train_test_split(X, y, test_size=0.2)
        ada2 = AdalineGD(n_iter=itera, eta=etaC).fit(Xl, yl)
        aux3 = ada2.predict(Xt)
        clf = SGDClassifier(loss="hinge", penalty="l2")
        clf.fit(Xl, yl)
        SGDClassifier(alpha=0.0001, average=False, class_weight=None, epsilon=0.1, eta0=etaC, fit_intercept=True,
                      l1_ratio=0.15, learning_rate='optimal', loss='hinge', max_iter=itera, n_iter=None, n_jobs=1,
                      penalty='l2', power_t=0.5, random_state=None, shuffle=True, tol=None, verbose=0, warm_start=False)


        auxError = 0
        resultAda2 = np.where(aux3 == yt, 'o', 'x')
        auxError = np.count_nonzero(resultAda2 == 'o') * 100 / len(resultAda2)
        errosAd2.append(auxError)
        auxError = 0
        esto = clf.predict(Xt)
        resultAda3 = np.where(esto == yt, 'o', 'x')
        auxError = np.count_nonzero(resultAda3 == 'o') * 100 / len(resultAda3)


        errosAd3.append(auxError)
        auxError = 0

        erro2 += np.count_nonzero(resultAda2 == 'o')
        erro3 += np.count_nonzero(resultAda3 == 'o')


    print "% Media dos acertos"
    print np.sum(errosAd2)/20
    print np.sum(errosAd3)/20
    print "Media dos acertos pra cada iteracao"
    print erro2/20
    print erro3/20
    print "Array das % de acertos"
    print errosAd2
    print errosAd3
    print "\n"




iris = datasets.load_iris()
haberman = pd.read_csv("https://archive.ics.uci.edu/ml/machine-learning-databases/haberman/haberman.data", header=None)
y = haberman.iloc[0:306, 3].values
#print y
y = np.where(y == 1, 1, -1)
X = haberman.iloc[0:306 , [0,1,2]].values
print  "haberman"
#calc(X,y, 0.0000001, 5000)



datab = datasets.load_digits()
XD = datab.data[:,:]
auxD = datab.target
YD = np.where(auxD == 0, 1, -1)
Xl,Xt,yl,yt = train_test_split(XD,YD,test_size=0.2)
print "Digitos"
#calc(XD,YD, 0.00000000001, 5000)

X = iris.data[:, :]
aux = iris.target
y = np.where(aux == 0, 1, -1)
print "Iris"
#calc(X,y, 0.0001, 1000)


poker = pd.read_csv("http://archive.ics.uci.edu/ml/machine-learning-databases/tae/tae.data", header=None)
yk = poker.iloc[0:151, 5].values
yk = np.where(yk == 1, 1, -1)
Xk = poker.iloc[0:1473 , [0,1,2,3,4]].values
print  "Teaching Assistant Evaluation"
#calc(Xk,yk, 0.000000000001, 1000)

